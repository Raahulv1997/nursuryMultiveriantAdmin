import React from "react";

function NotFound() {
  return <div className="container-fluid p-0"></div>;
}

export default NotFound;
