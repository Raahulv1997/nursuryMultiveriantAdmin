const statusJson = {
  statusjson: ["pending", "approved", "draft"],
  status_order: [
    "pending",
    "approved",
    "placed",
    "shipped",
    "delivered",
    "packed",
    "return",
    "cancel",
  ],
};
export default statusJson;
