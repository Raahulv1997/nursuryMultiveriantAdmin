import "./App.css";
import React from "react";

import Layout from "./layout";

function App() {
  return (
    <div className="container-fluid p-0">
      <Layout />
    </div>
  );
}

export default App;
